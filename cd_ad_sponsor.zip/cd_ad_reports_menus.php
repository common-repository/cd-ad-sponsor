<?php

if (!is_admin()) {
	die ("Unauthorized.");
}
/*
$cd_js = cd_get_plugin_dir()."/cd_ad_sponsor/js";
wp_register_script('cd_ad_report', $cd_js . '/cd_ad_report.js', array('jquery'));
wp_enqueue_script('cd_ad_report',$cd_js."/cd_ad_report.js");
*/

function cd_ad_make_reports_menu() {
	global $wpdb,$blog_id;
	ob_start();
	if ( isset($_REQUEST['cid']) && $_REQUEST['cid'] ) {
	$cd_cid = (int)$_REQUEST['cid'];
	} else {
		$cd_cid = 0;
	}
	$op = $_GET['op'];
	echo '<div class="wrap">
	<div class="icon32"><img src="'.cd_get_plugin_dir().'/cd_ad_sponsor/images/cd_ad_32.png" width="30px" height="31px" border="0" /></div>
	<h2>'.__('Banner Ad Report', 'cd_ad_sponsor').'</h2>';
	switch ($op) {
		case "view":
			echo '<h3>'.__('Itemized Report', 'cd_ad_sponsor').'</h3>';

$b_name = $wpdb->get_var("SELECT name FROM cd_ad_sponsor_banners AS b LEFT JOIN cd_ad_sponsor_schedule AS c ON b.bid=c.bid WHERE c.cid=$cd_cid");
echo '<p>The following table lists the click-through details for Banner Ad, <b><i>';
echo $b_name;
echo '</i></b>.</p>';
			echo '<div class="cd_render">';
			echo '<table class="widefat">
			<thead><tr>
			<th scope="col">'.__('Time Stamp', 'cd_ad_sponsor').'</th>
			<th scope="col">'.__('Visitor IP', 'cd_ad_sponsor').'</th>
			<th scope="col">'.__('Host Name', 'cd_ad_sponsor').'</th>
			<th scope="col">'.__('Whois', 'cd_ad_sponsor').'</th>
			<th scope="col">'.__('Exclude', 'cd_ad_sponsor').'</th>
			</tr></thead>
			<tbody>';
			$d_query = "SELECT timestamp, visitorIP FROM cd_ad_sponsor_clickthrough WHERE cid =$cd_cid AND blog_id =$blog_id ORDER BY timestamp";
			$cd_details = $wpdb->get_results($d_query,OBJECT);
			if (!empty($cd_details)) {
				foreach($cd_details as $ad_result) {
					echo '<tr>';
					echo '<td>'.$ad_result->timestamp.'</td>';
					echo '<td>'.$ad_result->visitorIP.'</td>';
					echo '<td>'.gethostbyaddr($ad_result->visitorIP).'</td>';
					echo '<td><a href="http://whois.domaintools.com/'.$ad_result->visitorIP.'" title="Domain Tool Whois '.$ad_result->visitorIP.' lookup." target="_blank"><img src="'.cd_get_plugin_dir().'/cd_ad_sponsor/images/cd_whois.png" alt="Domain Tool Whois '.$ad_result->visitorIP.' lookup." /></a></td>';
					echo '<td><a href="admin.php?page=cd_ad_reports_menu&op=add&cid='.$cd_cid.'&vip='.$ad_result->visitorIP.'" title="Add '.$ad_result->visitorIP.' to Excluded IP table."><img src="'.cd_get_plugin_dir().'/cd_ad_sponsor/images/cd_clear.png" alt="Add '.$ad_result->visitorIP.' to Excluded IP table." /></a></td>';
					echo '</tr>';
				}
			} else {
				echo '<tr><td colspan="5">No Banner Ad details found.</td></tr>';
			}
			echo '</tbody></table></div>';
			echo '<div style="border-top:1px solid #E0E0FF;"><p>You can use <a href="http://whois.domaintools.com/" title="Domain Tools Whois Lookup" target="_blank">Domain Tools Whois Lookup</a> to view additional IP address information to help determine whether to add the IP to the Excluded Table. All IP addresses you add to the Excluded Table are removed from the click-through counts for this Banner Ad.</p>';
			echo '</div>';
			break;

		case "add":
			$cd_exclude_ip = $_REQUEST['vip'];
			$cd_description = gethostbyaddr($cd_exclude_ip);
			$iquery = "INSERT INTO cd_ad_sponsor_excluded (aid,excludeIP,blog_id,description) VALUES (null,'$cd_exclude_ip','$blog_id','$cd_description')";
			$result = $wpdb->query($iquery);
			if ($result==1) {
				echo '<div id="message" class="updated fade"><p>IP Address &quot;'.$cd_exclude_ip.'&quot; added to Exclude Table.</p></div>';
				$wpdb->query("DELETE FROM cd_ad_sponsor_clickthrough WHERE blog_id=$blog_id AND visitorIP='".$cd_exclude_ip."'");
			} else {
				echo '<div id="message" class="updated fade"><p>Error adding IP Address &quot;'.$cd_exclude_ip.'&quot; to Exclude Table.</p></div>';
			}
			cd_ad_reports_render();
			break;

		default:
			cd_ad_reports_render();
	}


	echo '<br /><div style="clear:both;"></div></div>'."\n";

}


function cd_ad_reports_render() {
	global $wpdb,$blog_id;
	ob_start();
	echo '<p>The following table lists the basic statistics for the currently scheduled Banner Ads for blog, <b><i>';
	echo bloginfo('name');
	echo '</i></b>, grouped by sponsor.</p>';

	echo '<div class="cd_render">';

	echo '<table class="widefat">
	<thead><tr>
	<th scope="col">'.__('Banner Ad', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Start', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('End', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Clicks', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Impressions', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Ratio', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Rate', 'cd_ad_sponsor').'</th>
	</tr></thead>
	<tbody>';

	$cd_sponsor_name = $wpdb->get_results("SELECT sid,name FROM cd_ad_sponsor WHERE sid IN (SELECT sid FROM cd_ad_sponsor_schedule WHERE blog_id=$blog_id) ORDER BY name",OBJECT);
	if (!empty($cd_sponsor_name)) {
		foreach($cd_sponsor_name as $sponsor_result) {
			echo '<tr style="background-color:#FDFFBB;"><td colspan="7" style="font-size:12px;"><b><i>'.$sponsor_result->name.'</i></b></td></tr>';
			$cd_sponsor_ads = $wpdb->get_results("SELECT b.name, b.rev_id, c.cid, c.startdate, c.enddate, c.impressions FROM cd_ad_sponsor_schedule AS c JOIN cd_ad_sponsor_banners AS b ON b.bid = c.bid WHERE b.sid =$sponsor_result->sid AND b.blog_id =$blog_id ORDER BY b.name ASC", OBJECT);
			if ($cd_sponsor_ads) {
				foreach($cd_sponsor_ads as $ad_result) {
					(int)$cd_current = $wpdb->get_var("SELECT Count('cid') AS txt FROM cd_ad_sponsor_clickthrough WHERE cid=$ad_result->cid AND blog_id=$blog_id");
					echo '<tr>';
					if ($cd_current >= 1) {
						echo '<td><a href="admin.php?page=cd_ad_reports_menu&op=view&cid='.$ad_result->cid.'" title="View banner '.$ad_result->name.' details">'.$ad_result->name.'</td>';
					} else {
					echo '<td>'.$ad_result->name.'</td>';
					}
					echo '<td>'.$ad_result->startdate.'</td>';
					echo '<td>'.$ad_result->enddate.'</td>';
					echo '<td>'.$cd_current.'</td>';
					echo '<td>'.$ad_result->impressions.'</td>';
					if ($cd_current == 0) {
						echo '<td>0:0</td>';
					}else{
						echo '<td>1:'.(int)($cd_ratio = $ad_result->impressions / $cd_current).'</td>';
					}
					$cd_rate_result = $wpdb->get_row("SELECT name,rate FROM cd_ad_sponsor_revenue WHERE rev_id=$ad_result->rev_id");
					echo '<td>';
					if ($cd_rate_result) {
						$cd_rate = $cd_rate_result->rate;
						setlocale(LC_MONETARY, 'en_US');
						switch ($cd_rate_result->name) {
							case "CPD":
								$cd_dif = cd_get_date_ellapsed($ad_result->startdate);
								$cd_total = $cd_dif * $cd_rate;
								echo 'CPD: '.$cd_dif.' @ '.$cd_rate.'<br />'.money_format('%i', $cd_total);
								break;
							case "CPC":
								$cd_total = $cd_current * $cd_rate;
								echo 'CPC: '.$cd_current.' @ '.$cd_rate.'<br />'.money_format('%i', $cd_total);
								break;
							case "CPM":
								$cd_cpm = (int)($ad_result->impressions / 1000);
								$cd_total = $cd_cpm * $cd_rate;
								echo 'CPM: '.$cd_cpm.' @ '.$cd_rate.'<br />'.money_format('%i', $cd_total);
								break;
							case "FEE":
								$cd_total = $cd_rate;
								echo 'FEE: '.$cd_rate.'<br />'.money_format('%i', $cd_total);
								break;
							default:
								$cd_total = $cd_rate;
								echo $cd_rate_result->name.': '.$cd_rate.'<br />'.money_format('%i', $cd_total);
						}
					}
					echo '</td>';
					echo '</tr>';
				}
			}
		}
	}



	echo '</tbody></table></div><br />';

	echo '<div style="border-top:1px solid #E0E0FF;"><p>Banner Reports shows the current click-through to impressions ratio for the currently scheduled ads. Only those ads that have a click-through count are available for a detailed report. Click the Banner Name to view the itemized report.</p>
	<p>Rates are shown is USD funds only and indicate the Revenue Type assigned to this Banner Ad.</p>
	<p><b>Note:</b> If you are using WordPress<span style="font-size:12pt;">&#181;</span>, the Reports apply to the currently active blog only.</p>';
	cd_ad_admin_footer();
	echo '</div>';
}

?>
