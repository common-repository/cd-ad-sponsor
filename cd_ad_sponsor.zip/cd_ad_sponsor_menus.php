<?php

if (!is_admin()) {
	die ("Unauthorized.");
}

function cd_ad_make_management_menu() {
	global $wpdb;
	ob_start();
	if ( isset($_REQUEST['sid']) && $_REQUEST['sid'] ) {
		$cd_sid = (int)$_REQUEST['sid'];
	} else {
		$cd_sid = 0;
	}
	$op = $_REQUEST['op'];
	echo '<div class="wrap">
	<div class="icon32"><img src="'.cd_get_plugin_dir().'/cd_ad_sponsor/images/cd_ad_32.png" width="30px" height="31px" border="0" /></div>
	<h2>'.__('Manage Sponsors', 'cd_ad_sponsor').'</h2>';

	switch ($op) {
		case "add":
			if ($_POST['action'] == "addsponsor") {
				$cd_sponsor_name = $wpdb->escape($_POST['sponsor_name']);
				$cd_user_name = $wpdb->escape($_POST['user_name']);
				$cd_user_password = $wpdb->escape($_POST['user_password']);
				$cd_affiliate_id = $wpdb->escape($_POST['affiliate_id']);
				$cd_webmaster_link = $wpdb->escape($_POST['webmaster_link']);
				$cd_referral_url = $wpdb->escape($_POST['referral_url']);
				$cd_referral_banner = $wpdb->escape($_POST['referral_banner']);
				$cd_support_email = $wpdb->escape($_POST['support_email']);
				$cd_support_icq = $wpdb->escape($_POST['support_icq']);
				$cd_2257 = $wpdb->escape($_POST['docs_2257']);
				if ($cd_sponsor_name != "") {
					$result = $wpdb->query("INSERT INTO cd_ad_sponsor (sid,name,user,password,affiliate,wmlink,wmref_url,wmref_banner,docs_2257,wm_email,wmref_icq) VALUES (null,'$cd_sponsor_name','$cd_user_name','$cd_user_password','$cd_affiliate_id','$cd_webmaster_link','$cd_referral_url','$cd_referral_banner','$cd_2257','$cd_support_email','$cd_support_icq')");
					if ($result == 1) {
						echo '<div id="message" class="updated fade"><p>Sponsor &quot;'.$cd_sponsor_name.'&quot; created.</p></div>';
						cd_ad_sponsor_render();
						break;
					} else {
						echo '<div id="message" class="error fade"><p>Error creating sponsor.</p></div>';
					}
				} else {
					echo '<div id="message" class="error fade"><p>Sponsor Name is Required.</p></div>';
				}
			}
			echo '<h3>'.__('Add Sponsor', 'cd_ad_sponsor').'</h3>';
			echo '<p>Complete the following form to create a new sponsor. Fields marked <sup class="req">*</sup> are required.</p>';
			echo '<form action="admin.php?page=cd_ad_sponsor/cd_ad_sponsor.php" method="post" name="addsponsor" id="addsponsor">';
			echo '<table class="form-table">
			<tr class="form-field">
			<th scope="row"><label for="sponsor_name">Sponsor Name<sup class="req">*</sup></label>
			<input name="action" type="hidden" id="action" value="addsponsor" /><input name="op" type="hidden" id="op" value="add" /></th>
			<td><input name="sponsor_name" type="text" id="sponsor_name" value="'.$cd_sponsor_name.'" style="width:200px;" /><br /><span class="description">Enter the name of this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="user_name">User Name</label></th>
		<td><input name="user_name" type="text" id="user_name" value="'.$cd_user_name.'" style="width:200px;" /><br /><span class="description">Enter the user name used to login to this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="user_password">Login Password</label></th><td><input name="user_password" type="text" id="user_password" value="'.$cd_user_password.'" style="width:200px;" /><br /><span class="description">Enter the password used to log in to this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="affiliate_id">Affiliate ID</label></th><td><input name="affiliate_id" type="text" id="affiliate_id" value="'.$cd_affiliate_id.'" style="width:200px;" /><br /><span class="description">Enter the CCBill, NATS, or sponsor assigned Affiliate ID.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="webmaster_link">Webmaster URL</label></th><td><input name="webmaster_link" type="text" id="webmaster_link" value="'.$cd_webmaster_link.'" style="width:400px;" /><br /><span class="description">Enter the URI to log in to this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="referral_url">Referral URL</label></th><td><input name="referral_url" type="text" id="referral_url" value="'.$cd_referral_url.'" style="width:400px;" /><br /><span class="description">Enter the Webmaster Referral URI for this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="referral_banner">Referral Banner</label></th><td><input name="referral_banner" type="text" id="referral_banner" value="'.$cd_referral_banner.'" style="width:400px;" /><br /><span class="description">Enter the Webmaster Referral Banner URI for this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="docs_2257">2257 Doc URL</label></th><td><input name="docs_2257" type="text" id="docs_2257" value="'.$cd_2257.'" style="width:400px;" /><br /><span class="description">Enter the 2257 Documentation URI for this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="support_email">Sponsor Support Email</label></th><td><input name="support_email" type="text" id="support_email" value="'.$cd_support_email.'" style="width:320px;" /><br /><span class="description">Enter the support email for this sponsor.</span></td></tr>'."\n";
			echo '<tr class="form-field"><th scope="row"><label for="support_icq">Sponsor Support ICQ</label></th><td><input name="support_icq" type="text" id="support_icq" value="'.$cd_support_icq.'" style="width:200px;" /><br /><span class="description">Enter the supprt ICQ for this sponsor.</span></td></tr>'."\n";
			echo '</table>
			<p class="submit">
				<input name="addsponsor" type="submit" id="addsponsor" class="button" value="Save Changes" />
			</p>
			</form>';
			break;

		case "edit":
			if ($_POST['action'] == "editsponsor") {
				$cd_sponsor_name = $wpdb->escape($_POST['sponsor_name']);
				$cd_user_name = $wpdb->escape($_POST['user_name']);
				$cd_user_password = $wpdb->escape($_POST['user_password']);
				$cd_affiliate_id = $wpdb->escape($_POST['affiliate_id']);
				$cd_webmaster_link = $wpdb->escape($_POST['webmaster_link']);
				$cd_referral_url = $wpdb->escape($_POST['referral_url']);
				$cd_referral_banner = $wpdb->escape($_POST['referral_banner']);
				$cd_2257 = $wpdb->escape($_POST['docs_2257']);
				$cd_support_email = $wpdb->escape($_POST['support_email']);
				$cd_support_icq = $wpdb->escape($_POST['support_icq']);
				if ($cd_sponsor_name != "") {
					$result = $wpdb->query("UPDATE cd_ad_sponsor SET name='$cd_sponsor_name',user='$cd_user_name',password='$cd_user_password',affiliate='$cd_affiliate_id',wmlink='$cd_webmaster_link',wmref_url='$cd_referral_url',wmref_banner='$cd_referral_banner',docs_2257='$cd_2257',wm_email='$cd_support_email',wmref_icq='$cd_support_icq' WHERE sid='$cd_sid'");
					if ($result == 1) {
						echo '<div id="message" class="updated fade"><p>Sponsor &quot;'.$cd_sponsor_name.'&quot; updated.</p></div>';
						cd_ad_sponsor_render();
						break;
					} elseif ( $result == 0 ) {
						echo '<div id="message" class="updated fade"><p>No Updte Required.</p></div>';
						cd_ad_sponsor_render();
						break;
					} else {
						echo '<div id="message" class="error fade"><p>Error updating sponsor.</p></div>';
					}
				} else {
					echo '<div id="message" class="error fade"><p>Sponsor Name is Required.</p></div>';
				}
			} else {
				$result = $wpdb->get_row("SELECT * FROM cd_ad_sponsor WHERE sid='$cd_sid'");
				$cd_sponsor_name = stripslashes($result->name);
				$cd_user_name = stripslashes($result->user);
				$cd_user_password = stripslashes($result->password);
				$cd_affiliate_id = stripslashes($result->affiliate);
				$cd_webmaster_link = stripslashes($result->wmlink);
				$cd_referral_url = stripslashes($result->wmref_url);
				$cd_referral_banner = stripslashes($result->wmref_banner);
				$cd_2257 = stripslashes($result->docs_2257);
				$cd_support_email = stripslashes($result->wm_email);
				$cd_support_icq = stripslashes($result->wmref_icq);
			}
			echo '<h3>'.__('Edit Sponsor Details', 'cd_ad_sponsor').'</h3>';
			echo '<p>Modify the following information to change this sponsor\'s details. Fields marked <sup class="req">*</sup> are required.</p>'."\n";
			echo '<form action="admin.php?page=cd_ad_sponsor/cd_ad_sponsor.php" method="post" name="addsponsor" id="addsponsor">
';
			echo '<table class="form-table">
			<tr class="form-field">
			<th scope="row"><label for="sponsor_name">Sponsor Name<sup class="req">*</sup></label>
			<input name="action" type="hidden" id="action" value="editsponsor" /><input name="op" type="hidden" id="op" value="edit" /><input name="sid" type="hidden" id="sid" value="'.$cd_sid.'" /></th>
			<td><input name="sponsor_name" type="text" id="sponsor_name" value="'.$cd_sponsor_name.'" style="width:200px;" /><br /><span class="description">Enter the name of this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="user_name">User Name</label></th>
		<td><input name="user_name" type="text" id="user_name" value="'.$cd_user_name.'" style="width:200px;" /><br /><span class="description">Enter the user name used to login to this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="user_password">Login Password</label></th><td><input name="user_password" type="text" id="user_password" value="'.$cd_user_password.'" style="width:200px;" /><br /><span class="description">Enter the password used to log in to this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="affiliate_id">Affiliate ID</label></th><td><input name="affiliate_id" type="text" id="affiliate_id" value="'.$cd_affiliate_id.'" style="width:200px;" /><br /><span class="description">Enter the CCBill, NATS, or sponsor assigned Affiliate ID.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="webmaster_link">Webmaster URL</label></th><td><input name="webmaster_link" type="text" id="webmaster_link" value="'.$cd_webmaster_link.'" style="width:400px;" /><br /><span class="description">Enter the URI to log in to this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="referral_url">Referral URL</label></th><td><input name="referral_url" type="text" id="referral_url" value="'.$cd_referral_url.'" style="width:400px;" /><br /><span class="description">Enter the Webmaster Referral URI for this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="referral_banner">Referral Banner</label></th><td><input name="referral_banner" type="text" id="referral_banner" value="'.$cd_referral_banner.'" style="width:400px;" /><br /><span class="description">Enter the Webmaster Referral Banner URI for this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="docs_2257">2257 Doc URL</label></th><td><input name="docs_2257" type="text" id="docs_2257" value="'.$cd_2257.'" style="width:400px;" /><br /><span class="description">Enter the 2257 Documentation URI for this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="support_email">Sponsor Support Email</label></th><td><input name="support_email" type="text" id="support_email" value="'.$cd_support_email.'" style="width:320px;" /><br /><span class="description">Enter the support email for this sponsor.</span></td></tr>'."\n";

			echo '<tr class="form-field"><th scope="row"><label for="support_icq">Sponsor Support ICQ</label></th><td><input name="support_icq" type="text" id="support_icq" value="'.$cd_support_icq.'" style="width:200px;" /><br /><span class="description">Enter the supprt ICQ for this sponsor.</span></td></tr>'."\n";
			echo '</table>
			<p class="submit">
				<input name="editsponsor" type="submit" id="editsponsor" class="button" value="Save Changes" />
			</p>
			</form>';
			break;
		default:
			cd_ad_sponsor_render();
	}
	echo '<br /><div style="clear:both;"></div></div>'."\n";
}

function cd_ad_sponsor_render() {
	global $wpdb;
	ob_start();
	echo '<p>The following table lists all currently defined sponsors and their associated webmaster reference information.</p>';
	echo '<div class="submit">
	<a class="button" href="admin.php?page=cd_ad_sponsor/cd_ad_sponsor.php&op=add&pid=0" title="Add Sponsor">Add Sponsor</a></div>'."\n";
	echo '<div class="cd_render">';
	echo '<table class="widefat" width="99%">
	<thead><tr>
	<th scope="col">'.__('Sponsor', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('User Name', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Password', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Affiliate ID', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Webmaster Link', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Referral Link', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Referral Banner', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Support Email', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Support ICQ', 'cd_ad_sponsor').'</th>
	<th scope="col">'.__('Legal', 'cd_ad_sponsor').'</th>
	</tr></thead>
	<tbody>';

	$cd_ad_sponsors = $wpdb->get_results("SELECT * FROM cd_ad_sponsor ORDER BY name ASC", OBJECT);
	if ($cd_ad_sponsors) {
		foreach($cd_ad_sponsors as $result) {
			echo '<tr valign="top">';
			echo '<td width="100px"><strong><a href="admin.php?page=cd_ad_sponsor/cd_ad_sponsor.php&op=edit&sid='.$result->sid.'" title="Edit sponsor '.$result->name.' details.">'.$result->name.'</a></strong></td>';
			echo '<td>'.$result->user.'</td>';
			echo '<td>'.$result->password.'</td>';
			echo '<td>'.$result->affiliate.'</td>';
			echo '<td><a href="'.stripslashes($result->wmlink).'" target="_blank" title="Opens sponsor'.stripslashes($result->name).' in new window">'.$result->wmlink.'</a></td>';
			echo '<td>'.stripslashes($result->wmref_url).'</td>';
			echo '<td><div style="height:40px;width:auto;"><img src="'.stripslashes($result->wmref_banner).'" height="40px" width="auto" /></div></td>';
			echo '<td>'.stripslashes($result->wm_email).'</td>';
			echo '<td>'.stripslashes($result->wmref_icq).'</td>';
			echo '<td>';
			if ($result->docs_2257 != '') {
				echo 'Yes';
			} else {
				echo 'No';
			}
			echo'</td>';
			echo '</tr>'."\n";
		}
	} else {
		echo '<tr><td colspan="10"><b>No Sponsors Found.</b></td>';
	}
	echo '</tbody></table></div><br />'."\n";

	echo '<div style="border-top:1px solid #E0E0FF;"><p>The cd_ad_sponsor Plugin maintains a list of your sponsors (your clients), their associated ADs, including program types, revenue types, and scheduling, and the click-through and impressions resulting from the presentation of each AD.</p>
	<p><b>Note:</b> If you are using WordPress<span style="font-size:12pt;">&#181;</span>, the Sponsors you define apply across all blogs. That is, they are <i><b>not</b></i> blog specific. It is recommended that you define all Sponsors that you wish to promote regardless of the number of blogs you currently publish.</p>';
	cd_ad_admin_footer();
	echo '</div>';

}


?>