<?php

if (!is_admin()) {
	die ("Unauthorized.");
}

global $wpdb,$blog_id;

$cd_ad_sponsor_tables = array('cd_ad_sponsor','cd_ad_sponsor_banners','cd_ad_sponsor_clickthrough','cd_ad_sponsor_excluded','cd_ad_sponsor_program','cd_ad_sponsor_reports','cd_ad_sponsor_revenue','cd_ad_sponsor_rotation','cd_ad_sponsor_schedule','cd_ad_sponsor_zones');

$op = $_REQUEST['op'];

echo '<div class="wrap"><div class="icon32"><img src="'.cd_get_plugin_dir().'/cd_ad_sponsor/images/cd_ad_32.png" width="30px" height="31px" border="0" /></div>
<h2>'.__('Uninstall', 'cd_ad_sponsor').'</h2>';


switch ($op) {
	case ("uninstall"):
		echo '<div id="message" class="updated fade"><p>';
		foreach($cd_ad_sponsor_tables as $table) {
			$wpdb->query("DROP TABLE {$table}");
			echo '<span style="color: #F00000;">';
			printf(__('Table \'%s\' has been deleted.', 'cd_ad_sponsor'), "<strong><em>{$table}</em></strong>");
			echo '</span><br />';
		}
		echo '</p></div>';
		echo '<p>The cd_ad_sponsor plug-in database tables have been removed. You may now deactivate the cd_ad_sponsor plug-in.</p>';
	break;

	default:

		echo '<p>Deactivating the Ad Sponsor Plug-in does NOT remove the database tables. You can completely remove the database tables here.</p><p><strong><span style="color:#F00000;">Caution:</span> Uninstalling the Ad Sponsor Plug-in <i>CANNOT</i> be undone. It is recommended that you backup your database before uninstalling the plug-in.</strong></p>';

		echo '<div class="cd_render">';
		echo '<table class="widefat" width="99%">
<thead><tr>
<th scope="col">'.__('Ad Sponsor Tables', 'cd_ad_sponsor').'</th>
</tr></thead>
<tbody>';

		echo '<tr><td><ol>';

		foreach($cd_ad_sponsor_tables as $table) {
			echo '<li>'.$table.'</li>'."\n";
		}
		echo '</ol></td></tr></table></div><br />'."\n";

		echo '<div class="submit"><a class="button" href="admin.php?page=cd_ad_sponsor/cd_ad_sponsor_uninstall.php&op=uninstall" title="Uninstall Add Sponsor Plug-in">UNINSTALL</a></div>';

}

?>
