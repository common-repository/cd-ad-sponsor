jQuery(document).ready(function($){
	var puri = $('#plugin_uri').val();
	$('#reportstart,#reportend').datepick({beforeShow: customRange, dateFormat: 'yy-mm-dd', showOn: 'both', buttonImageOnly: true, buttonImage: '' + puri + '/cd_ad_sponsor/images/ico_cal.png'});
});
function customRange(input) {
	return {minDate: (input.id == "reportend" ? jQuery('#reportstart').datepick("getDate") : null), maxDate: (input.id == "reportstart" ? jQuery('#reportend').datepick("getDate") : null)};
}

jQuery(document).ready(function($){
	$('#csid').change(function() {
		var sid = $('#rsid').val(),
			puri = $('#plugin_uri').val(),
			suri = $('#site_uri').val(),
			cd_load = '<img src="' + puri + '/cd_ad_sponsor/images/cd_ad_loading.gif" alt="Loading..." />';
	$('#cd_loader').html(cd_load);
	$('#cd_loader').show();
	$.post(suri+"/wp-admin/admin-ajax.php",
		{action:"cd_ajax_reports",sponsorid: "" + sid + "", 'cookie': encodeURIComponent(document.cookie)},
		function(data){
			$('#cd_loader').hide(function(){
				$('#rtable').html('');
				$('#cd_loader').html('');
				$('#rtable').html(data);
			});
		},
		"html")
	});
	return false;
});
