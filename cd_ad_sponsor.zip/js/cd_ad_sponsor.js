jQuery(document).ready(function($){
	$('#psid').change(function() {
		var sid = $('#psid').val(),
			puri = $('#plugin_uri').val(),
			suri = $('#site_uri').val(),
			cd_load = '<img src="' + puri + '/cd_ad_sponsor/images/cd_ad_loading.gif" alt="Loading..." />';
	$('#cd_loader').html(cd_load);
	$('#cd_loader').show();
	$.post(suri+"/wp-admin/admin-ajax.php",
		{action:"cd_ajax_program",sponsorid: "" + sid + "", 'cookie': encodeURIComponent(document.cookie)},
		function(data){
			$('#cd_loader').hide(function(){
				$('#ppid').html(data);
				$('#cd_loader').html('');
			});
		},
		"html")
	});
	return false;
});

