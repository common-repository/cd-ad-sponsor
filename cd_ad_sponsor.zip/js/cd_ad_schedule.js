jQuery(document).ready(function($){
	var puri = $('#plugin_uri').val();
	$('#startdate,#enddate').datepick({beforeShow: customRange, dateFormat: 'yy-mm-dd', showOn: 'both', buttonImageOnly: true, buttonImage: '' + puri + '/cd_ad_sponsor/images/ico_cal.png'});
});
function customRange(input) {
	return {minDate: (input.id == "enddate" ? jQuery('#startdate').datepick("getDate") : null), maxDate: (input.id == "startdate" ? jQuery('#enddate').datepick("getDate") : null)};
}

jQuery(document).ready(function($){
	$('#csid').change(function() {
		var sid = $('#csid').val(),
			puri = $('#plugin_uri').val(),
			suri = $('#site_uri').val(),
			cd_load = '<img src="' + puri + '/cd_ad_sponsor/images/cd_ad_loading.gif" alt="Loading..." />';
	$('#cd_loader').html(cd_load);
	$('#cd_loader').show();
	$.post(suri+"/wp-admin/admin-ajax.php",
		{action:"cd_ajax_schedule",sponsorid: "" + sid + "", 'cookie': encodeURIComponent(document.cookie)},
		function(data){
			$('#cd_loader').hide(function(){
				$('#cbid').html(data);
				$('#cd_loader').html('');
			});
		},
		"html")
	});
	return false;
});
